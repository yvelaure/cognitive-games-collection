---
name: Performance issue
about: Report slow loading, lag, or performance problems
title: 'Performance: [Brief description]'
labels: 'performance'
assignees: ''

---

**Performance Issue Description**
Describe the performance problem you're experiencing.

**Affected Area**
Where are you experiencing the performance issue?
- [ ] Game loading
- [ ] Game gameplay
- [ ] Menu navigation
- [ ] Score saving
- [ ] App startup
- [ ] Transitions between games
- [ ] Overall app responsiveness

**Device Information**
- Device: [e.g. iPhone 12, Samsung Galaxy S21, Desktop PC]
- Operating System: [e.g. iOS 15, Android 11, Windows 10]
- Browser: [e.g. Chrome 96, Safari 15] (if web version)
- RAM: [e.g. 4GB, 8GB, Unknown]
- Internet Connection: [e.g. WiFi, 4G, 5G, Slow/Fast]

**Performance Details**
- How long does it take? [e.g. 10 seconds to load, 2-3 second delays]
- When does it happen? [e.g. always, after playing for X minutes, randomly]
- Does it get worse over time? [e.g. fine at first, then gets slower]

**Impact on Experience**
- [ ] Minor annoyance
- [ ] Significantly affects gameplay
- [ ] Makes the app unusable
- [ ] Causes crashes or freezing

**Steps to Reproduce**
1. Open [specific game/section]
2. [Specific actions that trigger the issue]
3. [When the performance issue occurs]

**Additional Context**
- Are other apps running simultaneously?
- Does closing and reopening help?
- Any error messages displayed?

**Screenshots/Video**
If possible, attach screenshots or screen recordings showing the performance issue.