---
name: New game suggestion
about: Suggest a new brain training game for the platform
title: 'Game Suggestion: [Game Name]'
labels: 'game-suggestion'
assignees: ''

---

**Game Name**
What would you call this game?

**Game Description**
Describe how the game works and what players need to do.

**Cognitive Skills Targeted**
What brain skills would this game help train?
- [ ] Memory
- [ ] Attention/Focus
- [ ] Processing Speed
- [ ] Problem Solving
- [ ] Pattern Recognition
- [ ] Mathematical Skills
- [ ] Spatial Reasoning
- [ ] Executive Function
- [ ] Other: ___________

**Game Mechanics**
How would players interact with the game?
- [ ] Tap/Click based
- [ ] Drag and drop
- [ ] Keyboard input
- [ ] Drawing/Tracing
- [ ] Multiple choice
- [ ] Time-based challenges
- [ ] Other: ___________

**Difficulty Progression**
How should the game get harder as players improve?

**Inspiration**
Is this based on existing games, research, or cognitive tests? Please share any references.

**Additional Features**
Any special features this game should have?
- [ ] Multiplayer/Competition
- [ ] Different themes/visuals
- [ ] Sound effects/music
- [ ] Achievements/Badges
- [ ] Statistics tracking
- [ ] Customizable difficulty

**Priority**
How important is this game addition?
- [ ] High - Would significantly enhance the platform
- [ ] Medium - Good addition to have
- [ ] Low - Nice to have eventually