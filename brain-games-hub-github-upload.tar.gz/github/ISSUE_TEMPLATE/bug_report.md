---
name: Bug report
about: Create a report to help us improve the Cognitive Training Hub
title: ''
labels: 'bug'
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Game Information (please complete the following information):**
 - Game: [e.g. IQ Challenge, Memory Master, Math Wizard]
 - Platform: [e.g. Web, Android, iOS]
 - Browser [e.g. chrome, safari] (if web)
 - Device: [e.g. iPhone6, Desktop, Samsung Galaxy]

**Additional context**
Add any other context about the problem here.

**Score/Progress Lost**
- [ ] Yes, I lost my game progress or score
- [ ] No, progress was maintained

**Error Details**
If you see any error messages, please include them here:
```
Paste error message here
```