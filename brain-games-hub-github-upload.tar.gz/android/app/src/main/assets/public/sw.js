// Brain Games Hub - Service Worker for PWA
const CACHE_NAME = 'brain-games-hub-v1.2';
const STATIC_CACHE_URLS = [
  '/simple-hub.html',
  '/complete-platform.html',
  '/two-screen-hub.html',
  '/manifest.json',
  '/sounds/hit.mp3',
  '/sounds/success.mp3',
  '/sounds/background.mp3',
  // Add other essential assets
];

// Install event - cache essential files
self.addEventListener('install', event => {
  console.log('🔧 Service Worker installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('📦 Caching essential files...');
        return cache.addAll(STATIC_CACHE_URLS);
      })
      .then(() => {
        console.log('✅ Service Worker installed successfully');
        self.skipWaiting();
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  console.log('🚀 Service Worker activating...');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            console.log('🗑️ Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      console.log('✅ Service Worker activated');
      self.clients.claim();
    })
  );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', event => {
  // Skip non-GET requests
  if (event.request.method !== 'GET') return;
  
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Return cached version if available
        if (response) {
          console.log('📦 Serving from cache:', event.request.url);
          return response;
        }
        
        // Otherwise fetch from network
        console.log('🌐 Fetching from network:', event.request.url);
        return fetch(event.request)
          .then(response => {
            // Don't cache if not a valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Clone the response
            const responseToCache = response.clone();
            
            // Cache the fetched response
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
            
            return response;
          })
          .catch(() => {
            // Offline fallback
            if (event.request.destination === 'document') {
              return caches.match('/simple-hub.html');
            }
          });
      })
  );
});

// Background sync for game data
self.addEventListener('sync', event => {
  if (event.tag === 'background-sync-game-data') {
    console.log('🔄 Background syncing game data...');
    event.waitUntil(syncGameData());
  }
});

async function syncGameData() {
  try {
    // Sync player progress, scores, achievements
    const gameData = localStorage.getItem('brainGamesPlayerData');
    if (gameData) {
      // Would sync to server in production
      console.log('✅ Game data synced successfully');
    }
  } catch (error) {
    console.error('❌ Background sync failed:', error);
  }
}

// Push notification handling
self.addEventListener('push', event => {
  console.log('📱 Push notification received');
  
  const options = {
    body: event.data ? event.data.text() : 'Time for your daily brain training!',
    icon: '/manifest.json',
    badge: '/manifest.json',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'play',
        title: 'Play Now',
        icon: '/manifest.json'
      },
      {
        action: 'later',
        title: 'Remind Later',
        icon: '/manifest.json'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('Brain Games Hub', options)
  );
});

// Notification click handling
self.addEventListener('notificationclick', event => {
  console.log('📱 Notification clicked:', event.action);
  event.notification.close();
  
  if (event.action === 'play') {
    event.waitUntil(
      clients.openWindow('/simple-hub.html')
    );
  } else if (event.action === 'later') {
    // Schedule reminder for later
    setTimeout(() => {
      self.registration.showNotification('Brain Games Hub', {
        body: 'Ready for some brain training?',
        icon: '/manifest.json'
      });
    }, 3600000); // 1 hour later
  }
});

console.log('🧠 Brain Games Hub Service Worker loaded');